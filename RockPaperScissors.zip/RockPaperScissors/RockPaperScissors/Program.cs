﻿using System;
namespace RockPaperScissors
{
    internal class Program
    {
        static void Main()
        {
            GameWorkFlow game = new GameWorkFlow();
            game.Run();
        }
    }
}